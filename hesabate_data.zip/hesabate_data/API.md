# Hesabate Store API

Reference doc for the Hesabate Store API used to sync store data (products, customers, orders, etc.) between Hesabate and this project. Reconstructed from the Postman docs (https://documenter.getpostman.com/view/5117721/2sAYdcrXsJ) plus live verification against the production server.

## Servers

| Host | Purpose | Notes |
|---|---|---|
| `s.hesabate.com` | **Production** | This account's real data lives here. Use this one. |
| `test.hesabate.com` | Test/demo | Separate database. Only recognizes the seeded demo account (`demo@test.ps` / `123`). Real accounts do **not** exist here — auth with a real account returns `{"status":"Error","code":"102","msg":"Error DB select"}`. |

Single endpoint for everything: `POST https://s.hesabate.com/store_api.php`

All requests are `multipart/form-data` (curl `--form` / Postman "formdata" body). There is no JSON body and no custom headers required — everything is a form field, including the auth token.

## Authentication

Two ways to authenticate a request:

1. **Username/password** (only for the `Auth` action, to obtain a token)
2. **Token** (for every other action — "used instead of username and pass")

### Get a token

```bash
curl -s -X POST "https://s.hesabate.com/store_api.php" \
  -F "username=YOUR_EMAIL" \
  -F "password=YOUR_PASSWORD" \
  -F "action=Auth"
```

Response:
```json
{"result":"Auth","token":"<opaque base64-looking string>"}
```

- The token is opaque (not a JWT) — don't try to decode/inspect it for claims.
- **Tokens appear to expire/rotate.** A token that worked before can later fail with `{"status":"Error","code":"100","msg":"Error Paramerters"}` even though all other fields are correct. If you see code 100, get a fresh token via `Auth` first before assuming the request payload is wrong.
- Pass the token as a form field named `token` on every subsequent request.

## Request shape

Every non-Auth request:

```
POST https://s.hesabate.com/store_api.php
Content-Type: multipart/form-data

token=<token>
action=download|upload
type=<endpoint type, for action=download>
...endpoint-specific fields
```

## Response shape

Success:
```json
{
  "status": "succes",
  "note": [["<column headers>"]],
  "table": [ { ...record... }, ... ]
}
```
(note the misspelling "succes" — that's the literal API output, not a typo in this doc.)

Error:
```json
{"status": "Error", "code": "<code>", "msg": "<message>"}
```

### Known error codes

| Code | Message | Meaning |
|---|---|---|
| 100 | `Error Paramerters` | Malformed/missing parameter, or (commonly) a stale/expired token. Get a fresh token and retry. |
| 102 | `Error DB select` | Underlying DB lookup failed — seen when authenticating with a username that doesn't exist on that server (e.g. a real account tried against `test.hesabate.com`). |
| 103 | `No Data available` | Query executed fine but returned zero rows. |

## Endpoints (`action=download`)

Auth token required on all of these (`token` field), omitted from the tables below for brevity.

| `type` | Extra params | Notes |
|---|---|---|
| `customers` | — | ✅ verified: returns customer records (name, address, phones, etc.) |
| `Banks` | — | ✅ verified: bank + branch list |
| `employers` | — | Returns "No Data available" for this account (no employer records exist) |
| `bank_accounts` | — | ✅ verified |
| `products` | `pro_id` (comma-separated IDs, blank = all), `all` (0=e-commerce items only, 1=all items), `view_items_by` (0=linked store only, 1=all stores), `production_only` (1=only items with production data, 2=only items with production data + its production data) | ⚠️ **Confirmed broken for this account** — returns "No Data available" under every parameter combination tried, despite the account having 585 products (see `products_min` / `products_prices` below, which return them fine). Likely a bug or an undocumented filter condition on this endpoint specifically. |
| `products_min` | `pro_id`, `view_items_by` | ✅ verified: 585 records, lighter product payload (id, category, name, price, main unit, brand, model, etc.) |
| `products_prices` | `onlyprice` (0=all prices, 1=one price) | ✅ verified: 585 records, per-product price list |
| `productBlock` | `block`, `all`, `view_items_by`, `production_only` | Not yet tested |
| `productIsAlive` | `block`, `all` | Not yet tested |
| `updateProductAmmount` | `view_items_by` | Not yet tested |
| `stores_product` | `last_op_date`, `allstores` (0=each store separately, 1=all stores combined) | ✅ verified: query succeeds, empty table for this account |
| `units` | — | ✅ verified |
| `same` (CustomCategories) | — | Empty for this account |
| `same_items` (CustomCategories Products) | — | Empty for this account |
| `customersBlock` | `block`, `cus_id` (0 = all) | Not yet tested |
| `customerPoints` | `customerId` (0 = all) | Not yet tested |
| `customer_report_update` | `customerId` | Not yet tested |
| `pointsCamp` | — | ✅ verified |
| `ColorMeasure` | — | ✅ verified |
| `ProductMeasuresBarcode` | — | ✅ verified: large dataset (~7,462 records) |
| `category` | — | ✅ verified |
| `customer_level` | — | ✅ verified |
| `posmenu` | — | ✅ verified: POS menu groups + items |
| `company` | — | ✅ verified |
| `trades` | — | ✅ verified |
| `style` | — | Empty for this account |
| `model` | — | Empty for this account |
| `color` | — | ✅ verified |
| `order_status` | — | ✅ verified |
| `city` | — | ✅ verified |
| `stores` | — | ✅ verified |
| `currency` | — | ✅ verified: single default currency |
| `currencys` | — | ✅ verified: full currency list with rates |
| `prices` | — | Not yet tested |
| `showBillInfo` | `billId` (comma-separated, the reference ID returned after insert), `invoice_type` (0=sales, 1=sale request, 13=POS invoice), `ids` (comma-separated, ID used in "send Order") | Not yet tested |

## Endpoints (`action=upload`)

These mutate data on the live account — treat as write operations, don't run them against production without confirming with the account owner first.

### `insert_customer`
```
action=upload
insert_customer=[{"name":"...","address":"...","phone1":"...","mobile":"...","work_place":"lat,lng"}]
```
JSON array of customer objects, form-encoded as a string.

### Send orders (`invoices`)
```
action=upload
invoice_type=0        # 0 sales, 1 sale request, 2 sale_return, 3 sale receipt, 17 sale_offer
transfer_price=0
customer_level=2
price_show=1
invoices={ "<local_id>": { ...order object... } }
invoice_update=0      # 0 new, 1 update
store_id=0            # 0 = default store for user
```

### Send POS orders
Same shape as "send orders" but `invoice_type` fixed to `13`.

### Send Production Order (`production_items`)
```
action=upload
production_items={ "<local_id>": { "id", "order_date", "unit", "amount", "product_id", "store_id", "over_all_cost", "order_details": [...] } }
```

### Send voucher (`vouchers`)
```
action=upload
vouchers={ "<local_id>": { "customer_id", "order_date", "total", "credits", "credits_currency_id", "credits_currency_rate", "checks": [...], "cash": [...] } }
invoice_update=0
```

### Delete Invoice
```
action=upload
delete_invoice=<invoice number>
invoice_type=0   # 0 sales, 1 sale request, 16 vouchers
```

## Verified end-to-end (2026-09-05)

Ran against `s.hesabate.com` with this account's real credentials:

1. `Auth` → returned a valid token.
2. Pulled every read-only `download` type listed above as ✅ verified and saved the raw responses to this folder (`hesabate_data/*.json`).
3. Confirmed `type=products` is broken for this account (585 products exist per `products_min`/`products_prices`, but `products` always reports "No Data available") — worth reporting to Hesabate/the API owner.

No `upload` actions were executed — those would create/modify real data on the live account.
